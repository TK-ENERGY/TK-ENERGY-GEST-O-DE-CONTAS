
import React, { useState, useMemo, useEffect } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid,
  Cell,
  LineChart,
  Line,
  LabelList
} from 'recharts';
import { 
  Users, 
  ChevronLeft, 
  User as UserIcon, 
  Zap, 
  DollarSign, 
  Calendar, 
  ArrowRight, 
  Search, 
  CheckCircle, 
  AlertCircle, 
  MapPin, 
  Download, 
  Info, 
  LogOut, 
  Mail, 
  Sun, 
  Leaf, 
  Lock, 
  Eye, 
  EyeOff, 
  ShieldCheck, 
  Phone, 
  Percent, 
  TrendingDown, 
  Database, 
  Layers, 
  Edit2, 
  Save, 
  X, 
  Type as TypeIcon, 
  Hash, 
  Layout,
  ChevronRight,
  UserPlus,
  ArrowUpRight,
  Plus,
  TrendingUp,
  Heart,
  Shield,
  Activity,
  Flag,
  Tag,
  Clock,
  CreditCard
} from 'lucide-react';

import { MOCK_CLIENTS, MOCK_FINANCIAL, MOCK_PLANTS } from './constants';
import { Client, InvoiceItem, Plant, FinancialSummary } from './types';
import { Logo } from './components/Logo';
import { DesktopHeader, BottomNavigation } from './components/Navigation';

const MONTHS = [
  'JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 
  'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'
];

// --- Shared Components ---

const DarkThemeWrapper = ({ children }: { children?: React.ReactNode }) => (
  <div className="min-h-[calc(100vh-120px)] relative overflow-hidden rounded-[2.5rem] md:rounded-[3rem] p-4 md:p-10 animate-fade-in shadow-2xl">
    <div className="absolute inset-0 z-0">
      <div className="absolute inset-0 bg-gradient-to-br from-[#000d1a] via-tk-dark to-[#002b5c]"></div>
      <div className="absolute top-[-15%] left-[-5%] w-[600px] h-[600px] bg-tk-blue rounded-full blur-[140px] opacity-40 animate-pulse"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-tk-gold rounded-full blur-[120px] opacity-25"></div>
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
    </div>
    <div className="relative z-10">
      {children}
    </div>
  </div>
);

const MonthSelector = ({ 
  selectedMonth, 
  onSelect, 
  onAddClient 
}: { 
  selectedMonth: string, 
  onSelect: (m: string) => void,
  onAddClient?: () => void
}) => {
  return (
    <div className="w-full flex items-center gap-4">
      <div className="flex-1 overflow-x-auto pb-2 scrollbar-hide">
        <div className="flex gap-2 min-w-max">
          {MONTHS.map((month) => (
            <button
              key={month}
              onClick={() => onSelect(month)}
              className={`
                w-12 h-12 md:w-14 md:h-14 flex items-center justify-center rounded-xl font-black text-xs transition-all duration-300 border-2
                ${selectedMonth === month 
                  ? 'bg-tk-gold border-tk-gold text-tk-dark shadow-lg shadow-tk-gold/20 scale-110 z-10' 
                  : 'bg-white/10 border-white/5 text-gray-400 hover:border-white/20 hover:bg-white/20'
                }
              `}
            >
              {month}
            </button>
          ))}
        </div>
      </div>
      
      {onAddClient && (
        <button
          onClick={onAddClient}
          title="Adicionar Novo Item"
          className="flex-shrink-0 w-12 h-12 md:w-14 md:h-14 bg-tk-blue text-white rounded-xl flex items-center justify-center border-2 border-tk-blue/20 hover:bg-tk-dark hover:scale-110 transition-all duration-300 shadow-lg shadow-tk-blue/20 group"
        >
          <Plus size={24} className="group-hover:rotate-12 transition-transform" />
        </button>
      )}
    </div>
  );
};

// --- View Components ---

const FinancialReportView = ({ 
  summary, 
  clients, 
  plants,
  onUpdateSummary,
  onUpdatePlant,
  onAddPlant
}: { 
  summary: FinancialSummary, 
  clients: Client[], 
  plants: Plant[],
  onUpdateSummary: (s: FinancialSummary) => void,
  onUpdatePlant: (p: Plant) => void,
  onAddPlant: () => void
}) => {
  const [isEditingMain, setIsEditingMain] = useState(false);
  const [localSummary, setLocalSummary] = useState(summary);
  const [editingPlantId, setEditingPlantId] = useState<string | null>(null);

  const chartData = [
    { name: 'LUCRO', value: localSummary.profit, color: '#22C55E' },
    { name: 'DESPESAS', value: localSummary.payments, color: '#EF4444' }
  ];

  const handleSaveSummary = () => {
    onUpdateSummary(localSummary);
    setIsEditingMain(false);
  };

  const renderCustomizedLabel = (props: any) => {
    const { x, y, width, value } = props;
    return (
      <g>
        <text 
          x={x + width / 2} 
          y={y - 12} 
          fill="#FFF" 
          textAnchor="middle" 
          dominantBaseline="middle" 
          className="text-[10px] font-black"
        >
          R$ {value.toLocaleString('pt-BR', { maximumFractionDigits: 0 })}
        </text>
      </g>
    );
  };

  return (
    <DarkThemeWrapper>
      <div className="space-y-12">
        {/* SEÇÃO SUPERIOR: HERO FINANCEIRO */}
        <section className="space-y-6">
          <div className="bg-white/10 backdrop-blur-xl rounded-[2.5rem] p-6 md:p-10 shadow-2xl border border-white/10 relative overflow-hidden group">
            <div className="absolute top-4 right-4 z-20">
              <button 
                onClick={() => isEditingMain ? handleSaveSummary() : setIsEditingMain(true)}
                className={`p-3 rounded-2xl transition-all shadow-lg ${isEditingMain ? 'bg-green-500 text-white' : 'bg-tk-gold text-tk-dark'}`}
              >
                {isEditingMain ? <Save size={20} /> : <Edit2 size={20} />}
              </button>
            </div>

            <div className="relative z-10 flex flex-col lg:flex-row gap-10">
              <div className="flex-1 space-y-8">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 mb-2">
                     <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                     <p className="text-[10px] font-black text-tk-gold uppercase tracking-[0.3em]">Gestão TK ENERGY - Operacional</p>
                  </div>
                  <div className="flex flex-wrap items-baseline gap-4">
                    {isEditingMain ? (
                      <div className="flex items-center gap-2">
                        <span className="text-3xl font-black text-white">R$</span>
                        <input 
                          type="number"
                          value={localSummary.profit}
                          onChange={e => setLocalSummary({...localSummary, profit: Number(e.target.value)})}
                          className="bg-white/5 border border-white/10 rounded-2xl px-4 py-2 text-4xl md:text-5xl font-black text-white outline-none w-64"
                        />
                      </div>
                    ) : (
                      <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter drop-shadow-sm">
                        R$ {localSummary.profit.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </h1>
                    )}
                    <div className="flex items-center gap-1 bg-white/10 text-green-400 px-3 py-2 rounded-2xl text-xs font-black border border-white/5">
                      <TrendingUp size={14} /> +{localSummary.growthPercent}%
                    </div>
                  </div>
                  <p className="text-lg font-bold text-gray-400 mt-1 uppercase tracking-wider">Lucro Líquido Consolidado</p>
                </div>

                <div className="space-y-4">
                  <p className="text-[10px] font-black text-tk-gold uppercase tracking-widest flex items-center gap-2">
                    <Layout size={12} /> Detalhamento de Lucro por Unidade
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-64 overflow-y-auto pr-2 scrollbar-hide">
                    {clients.map(client => {
                      const clientProfit = client.lastInvoice.amount * 0.15;
                      return (
                        <div key={client.id} className="bg-white/5 p-4 rounded-2xl border border-white/5 flex justify-between items-center hover:bg-white/10 transition-all cursor-default">
                          <div className="space-y-0.5">
                            <p className="text-[10px] font-black text-white uppercase truncate max-w-[120px]">{client.name}</p>
                            <p className="text-[9px] text-gray-500 font-bold font-mono">{client.contractId}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-black text-tk-gold">R$ {clientProfit.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                            <span className="text-[8px] font-bold text-gray-500 uppercase">ESTIMADO</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div className="w-full lg:w-96 bg-white/5 backdrop-blur-md rounded-[2.5rem] p-8 border border-white/5 shadow-xl">
                 <div className="flex items-center justify-between mb-8">
                    <p className="text-[10px] font-black text-tk-gold uppercase tracking-widest">Performance de Caixa</p>
                    <DollarSign size={16} className="text-tk-gold" />
                 </div>
                 
                 {isEditingMain && (
                   <div className="space-y-4 mb-6 animate-fade-in">
                     <div className="space-y-1">
                        <label className="text-[9px] font-black text-gray-500 uppercase">Total Despesas</label>
                        <input 
                          type="number"
                          value={localSummary.payments}
                          onChange={e => setLocalSummary({...localSummary, payments: Number(e.target.value)})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white font-bold outline-none"
                        />
                     </div>
                   </div>
                 )}

                 <div className="h-64 w-full">
                   <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData} margin={{ top: 30, right: 10, left: 10, bottom: 20 }}>
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#6B7280', fontSize: 10, fontWeight: 900 }} dy={10} />
                        <Tooltip contentStyle={{ backgroundColor: '#00204A', border: 'none', borderRadius: '12px', color: '#FFF' }} />
                        <Bar dataKey="value" radius={[12, 12, 12, 12]} barSize={50} label={renderCustomizedLabel}>
                          {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} fillOpacity={0.8} />
                          ))}
                        </Bar>
                      </BarChart>
                   </ResponsiveContainer>
                 </div>
              </div>
            </div>
          </div>
        </section>

        {/* SEÇÃO INTERMEDIÁRIA: BENEFICIÁRIOS */}
        <section className="space-y-4">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-2xl font-black text-white flex items-center gap-2">
              <Users size={24} className="text-tk-gold" />
              Impacto por Beneficiário
            </h2>
          </div>
          <div className="flex gap-6 overflow-x-auto pb-6 scrollbar-hide">
             {clients.map((client) => (
               <div key={client.id} className="flex-shrink-0 text-center">
                  <div className="relative mb-3">
                     <div className="w-20 h-20 bg-white/10 rounded-full border-2 border-white/20 shadow-lg flex items-center justify-center text-tk-gold overflow-hidden">
                        <UserIcon size={32} />
                     </div>
                     <div className="absolute -bottom-1 -right-1 bg-tk-gold text-tk-dark text-[10px] font-black px-2 py-1 rounded-full shadow-lg">
                       R$ {client.totalDiscountGenerated?.toFixed(0)}
                     </div>
                  </div>
                  <p className="text-[10px] font-black text-gray-400 uppercase truncate w-20">{client.name.split(' ')[0]}</p>
               </div>
             ))}
          </div>
        </section>

        {/* SEÇÃO INFERIOR: USINAS */}
        <section className="space-y-6">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-2xl font-black text-white flex items-center gap-2">
              <Zap size={24} className="text-tk-gold" /> Grid de Ativos
            </h2>
            <button 
              onClick={onAddPlant}
              className="p-3 bg-tk-blue text-white rounded-2xl shadow-lg hover:scale-110 transition-all active:scale-95"
            >
              <Plus size={20} />
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {plants.map((plant) => (
              <PlantCard 
                key={plant.id} 
                plant={plant} 
                isEditing={editingPlantId === plant.id}
                onEdit={() => setEditingPlantId(plant.id)}
                onCancel={() => setEditingPlantId(null)}
                onSave={(p) => { onUpdatePlant(p); setEditingPlantId(null); }}
              />
            ))}
          </div>
        </section>
      </div>
    </DarkThemeWrapper>
  );
};

interface PlantCardProps {
  plant: Plant;
  isEditing: boolean;
  onEdit: () => void;
  onSave: (p: Plant) => void;
  onCancel: () => void;
}

const PlantCard: React.FC<PlantCardProps> = ({ 
  plant, 
  isEditing, 
  onEdit, 
  onSave, 
  onCancel 
}) => {
  const [localPlant, setLocalPlant] = useState(plant);

  useEffect(() => {
    setLocalPlant(plant);
  }, [plant]);

  return (
    <div className="bg-white/5 backdrop-blur-lg rounded-[2rem] border border-white/10 p-6 space-y-4 hover:bg-white/10 transition-all relative overflow-hidden group">
      <div className="absolute top-3 right-3 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
        <button 
          onClick={() => isEditing ? onSave(localPlant) : onEdit()}
          className={`p-2 rounded-xl ${isEditing ? 'bg-green-500' : 'bg-white/10'} text-white transition-all`}
        >
          {isEditing ? <Save size={14} /> : <Edit2 size={14} />}
        </button>
      </div>

      <div className="flex justify-between items-start">
        <div className="flex-1 mr-4">
          {isEditing ? (
            <input 
              value={localPlant.name}
              onChange={e => setLocalPlant({...localPlant, name: e.target.value})}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-white font-black text-lg outline-none"
            />
          ) : (
            <h3 className="text-lg font-black text-white">{plant.name}</h3>
          )}
          
          {isEditing ? (
            <input 
              value={localPlant.location}
              onChange={e => setLocalPlant({...localPlant, location: e.target.value})}
              className="w-full mt-1 bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-tk-gold text-[10px] outline-none"
            />
          ) : (
            <p className="text-[10px] text-tk-gold font-bold flex items-center gap-1 uppercase tracking-widest"><MapPin size={10} /> {plant.location}</p>
          )}
        </div>
        {!isEditing && <CheckCircle size={20} className="text-green-500" />}
      </div>

      <div className="flex items-center justify-between py-3 border-y border-white/5">
        <span className="text-[9px] font-black text-gray-500 uppercase">Inversor</span>
        {isEditing ? (
          <select 
            value={localPlant.inverterBrand}
            onChange={e => setLocalPlant({...localPlant, inverterBrand: e.target.value as any})}
            className="bg-tk-dark border border-white/10 rounded-lg px-2 py-1 text-xs text-white outline-none"
          >
            <option value="Huawei">Huawei</option>
            <option value="Fronius">Fronius</option>
            <option value="Growatt">Growatt</option>
          </select>
        ) : (
          <span className="text-sm font-black text-white">{plant.inverterBrand}</span>
        )}
      </div>

      <div className="flex justify-between gap-4">
        <div className="flex-1">
          <span className="text-[9px] font-bold text-gray-500 uppercase block mb-1">Hoje</span>
          {isEditing ? (
            <div className="flex items-center gap-1">
              <input 
                type="number"
                value={localPlant.generationToday}
                onChange={e => setLocalPlant({...localPlant, generationToday: Number(e.target.value)})}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-white text-sm outline-none font-black"
              />
              <span className="text-[10px] text-gray-500 font-bold">kW</span>
            </div>
          ) : (
            <p className="text-xl font-black text-white">{plant.generationToday}k</p>
          )}
        </div>
        <div className="flex-1 text-right">
          <span className="text-[9px] font-bold text-gray-500 uppercase block mb-1">Mês</span>
          {isEditing ? (
             <div className="flex items-center gap-1">
              <input 
                type="number"
                value={localPlant.generationMonth}
                onChange={e => setLocalPlant({...localPlant, generationMonth: Number(e.target.value)})}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-tk-gold text-sm outline-none font-black text-right"
              />
              <span className="text-[10px] text-gray-500 font-bold">MW</span>
            </div>
          ) : (
            <p className="text-xl font-black text-tk-gold">{plant.generationMonth}M</p>
          )}
        </div>
      </div>
    </div>
  );
};

const NewPlantModal = ({ isOpen, onClose, onSave }: { isOpen: boolean, onClose: () => void, onSave: (plant: Plant) => void }) => {
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [brand, setBrand] = useState<'Huawei' | 'Fronius' | 'Growatt'>('Huawei');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newPlant: Plant = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      location,
      inverterBrand: brand,
      generationToday: 0,
      generationMonth: 0,
      trend: [0, 0, 0, 0, 0, 0, 0]
    };
    onSave(newPlant);
    onClose();
    setName('');
    setLocation('');
    setBrand('Huawei');
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-tk-dark/80 backdrop-blur-md animate-fade-in">
      <div className="bg-tk-dark rounded-[2.5rem] w-full max-w-lg overflow-hidden shadow-2xl border border-white/10">
        <div className="p-8 text-white relative border-b border-white/5">
           <button onClick={onClose} className="absolute top-6 right-6 p-2 hover:bg-white/10 rounded-full"><X size={24} /></button>
           <div className="flex items-center gap-4">
              <div className="p-4 bg-tk-gold rounded-2xl text-tk-dark"><Zap size={28} /></div>
              <div>
                <h2 className="text-2xl font-black">Novo Sistema</h2>
                <p className="text-gray-400 text-sm">Cadastre uma nova usina no grid.</p>
              </div>
           </div>
        </div>
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
           <div className="space-y-1">
              <label className="text-[10px] font-black text-tk-gold uppercase tracking-widest ml-1">Nome da Usina</label>
              <input required value={name} onChange={e => setName(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-white font-bold outline-none" placeholder="Ex: UFV Estrela" />
           </div>
           <div className="space-y-1">
              <label className="text-[10px] font-black text-tk-gold uppercase tracking-widest ml-1">Localização</label>
              <input required value={location} onChange={e => setLocation(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-white font-bold outline-none" placeholder="Ex: Sobral / CE" />
           </div>
           <div className="space-y-1">
              <label className="text-[10px] font-black text-tk-gold uppercase tracking-widest ml-1">Marca do Inversor</label>
              <select 
                value={brand} 
                onChange={e => setBrand(e.target.value as any)} 
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-white font-bold outline-none appearance-none"
              >
                <option value="Huawei">Huawei</option>
                <option value="Fronius">Fronius</option>
                <option value="Growatt">Growatt</option>
              </select>
           </div>
           <button type="submit" className="w-full bg-tk-gold text-tk-dark font-black py-5 rounded-2xl shadow-xl hover:bg-amber-400 transition-all uppercase tracking-widest text-xs">ADICIONAR USINA AO GRID</button>
        </form>
      </div>
    </div>
  );
};

const ManagementGrid = ({ 
  clients, 
  onSelectClient, 
  selectedMonth, 
  onSelectMonth 
}: { 
  clients: Client[], 
  onSelectClient: (client: Client) => void,
  selectedMonth: string,
  onSelectMonth: (m: string) => void
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const filteredClients = useMemo(() => 
    clients.filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()) || c.contractId.includes(searchTerm)), 
  [searchTerm, clients]);

  return (
    <DarkThemeWrapper>
      <div className="space-y-6 md:space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1">
            <h1 className="text-3xl md:text-4xl font-black text-white tracking-tighter flex items-center gap-3">
              <Users className="text-tk-gold" size={32} />
              Gestão de Consumidores
            </h1>
            <p className="text-gray-400 font-medium text-base md:text-lg">Painel administrativo da carteira ativa.</p>
          </div>
          <div className="relative w-full md:w-96">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={20} />
            <input 
              type="text" placeholder="Pesquisar Unidade..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 md:py-4 bg-white/5 border border-white/10 rounded-2xl text-white outline-none focus:ring-2 focus:ring-tk-gold transition-all"
            />
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-md p-4 md:p-6 rounded-3xl border border-white/5 space-y-4 shadow-xl">
          <p className="text-[10px] font-black text-tk-gold uppercase tracking-[0.3em] mb-1">Período de Referência Ativo</p>
          <MonthSelector selectedMonth={selectedMonth} onSelect={onSelectMonth} />
        </div>

        {/* GRID ADJUSTED FOR FULLSCREEN DISTRIBUTION */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-4 gap-6 md:gap-8">
          {filteredClients.map(client => {
            const discountVal = client.totalDiscountGenerated || 0;
            const originalVal = client.lastInvoice.amount + discountVal;
            const discountPercent = originalVal > 0 ? ((discountVal / originalVal) * 100).toFixed(1) : "0";

            return (
              <div 
                key={client.id} onClick={() => onSelectClient(client)} 
                className="bg-white/10 backdrop-blur-lg rounded-[2.5rem] md:rounded-[3rem] border border-white/10 p-5 md:p-7 shadow-2xl hover:scale-[1.02] transition-all duration-500 cursor-pointer flex flex-col group relative overflow-hidden h-full"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-tk-gold/5 rounded-full blur-3xl group-hover:bg-tk-gold/10 transition-all"></div>
                
                <div className="flex justify-between items-start mb-5 relative z-10">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-tk-gold/20 rounded-xl text-tk-gold group-hover:bg-tk-gold group-hover:text-tk-dark transition-all shadow-inner">
                      <UserIcon size={20} />
                    </div>
                    <div className="space-y-0.5">
                      <p className="text-[9px] md:text-[10px] text-tk-gold font-mono font-black tracking-widest uppercase">{client.contractId}</p>
                      <span className="text-[8px] font-black text-white/40 bg-white/5 px-1.5 py-0.5 rounded-full uppercase border border-white/5">{selectedMonth}/23</span>
                    </div>
                  </div>
                  <div className="p-1.5 bg-white/5 rounded-lg text-white/20 group-hover:text-tk-gold transition-colors">
                    <ArrowUpRight size={18} />
                  </div>
                </div>

                <div className="mb-5 relative z-10">
                  <h3 className="text-xl md:text-2xl font-black text-white leading-tight mb-1 truncate group-hover:text-tk-gold transition-colors">{client.name}</h3>
                  <div className="w-10 h-1 bg-tk-gold/30 rounded-full group-hover:w-16 transition-all duration-500"></div>
                </div>

                <div className="space-y-4 pt-5 border-t border-white/5 flex-1 relative z-10">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-green-500/10 rounded-xl text-green-400">
                      <DollarSign size={18} />
                    </div>
                    <div>
                      <p className="text-[9px] text-gray-500 font-black uppercase tracking-widest mb-0.5">Fatura Atual</p>
                      <p className="text-2xl md:text-3xl font-black text-white tracking-tighter leading-none">R$ {client.lastInvoice.amount.toLocaleString('pt-BR')}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-tk-blue/20 rounded-xl text-tk-blue">
                      <Zap size={18} />
                    </div>
                    <div>
                      <p className="text-[9px] text-gray-500 font-black uppercase tracking-widest mb-0.5">Consumo</p>
                      <p className="text-2xl md:text-3xl font-black text-white tracking-tighter leading-none">{client.lastInvoice.consumption} <span className="text-xs text-gray-500 font-bold ml-0.5 uppercase">kWh</span></p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 px-3 py-2.5 md:py-3 bg-white/5 rounded-2xl border border-white/5 group-hover:bg-white/10 transition-all">
                    <div className="p-2 bg-tk-gold/20 rounded-lg text-tk-gold">
                      <Tag size={16} />
                    </div>
                    <div className="flex-1 overflow-hidden">
                      <p className="text-[8px] text-tk-gold font-black uppercase tracking-widest mb-0.5">Economia Gerada</p>
                      <div className="flex items-baseline justify-between gap-2">
                        <p className="text-lg font-black text-white truncate">R$ {discountVal.toLocaleString('pt-BR')}</p>
                        <span className="flex-shrink-0 text-[8px] font-black text-green-400 bg-green-400/10 px-1.5 py-0.5 rounded-full border border-green-400/20">-{discountPercent}%</span>
                      </div>
                    </div>
                  </div>

                  {/* CAIXAS DE COMPROVAÇÃO DE PAGAMENTO - COMPACTED */}
                  <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-white/5">
                    <div className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-0.5 transition-all ${client.status === 'Em dia' ? 'bg-green-500/10 border-green-500/20 text-green-400' : 'bg-red-500/10 border-red-500/20 text-red-400'}`}>
                      <CheckCircle size={12} className={client.status === 'Em dia' ? 'opacity-100' : 'opacity-30'} />
                      <span className="text-[7px] font-black uppercase tracking-tighter text-center leading-tight">Pagto Cliente</span>
                    </div>
                    <div className="p-2 rounded-xl border border-white/5 bg-white/5 text-white/30 flex flex-col items-center justify-center gap-0.5 group-hover:bg-white/10 transition-all">
                      <Clock size={12} />
                      <span className="text-[7px] font-black uppercase tracking-tighter text-center leading-tight">Pagto Enel</span>
                    </div>
                  </div>
                </div>

                <div className="mt-6 flex items-center justify-between text-tk-gold/60 group-hover:text-tk-gold transition-all relative z-10">
                  <span className="text-[10px] font-black uppercase tracking-[0.2em]">Dashboard Completo</span>
                  <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </DarkThemeWrapper>
  );
};

// --- Modals & Invoices ---

const NewClientModal = ({ isOpen, onClose, onSave }: { isOpen: boolean, onClose: () => void, onSave: (client: Client) => void }) => {
  const [name, setName] = useState('');
  const [uc, setUc] = useState('');
  const [address, setAddress] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newClient: Client = {
      id: Math.random().toString(36).substr(2, 9),
      name, contractId: uc, status: 'Em dia', address,
      lastInvoice: {
        amount: 0, consumption: 0, dueDate: '10/01/2024',
        items: [
          { description: 'Energia Ativa (TUSD/TE)', value: 0 },
          { description: 'Iluminação Pública', value: 0 },
          { description: 'Adicional Bandeira Vermelha', value: 0 }
        ]
      },
      history: Array(6).fill(0).map((_, i) => ({ month: MONTHS[i], kwh: 0, amount: 0 }))
    };
    onSave(newClient); onClose(); setName(''); setUc(''); setAddress('');
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-tk-dark/80 backdrop-blur-md animate-fade-in">
      <div className="bg-tk-dark rounded-[2.5rem] w-full max-w-lg overflow-hidden shadow-2xl border border-white/10">
        <div className="p-8 text-white relative border-b border-white/5">
           <button onClick={onClose} className="absolute top-6 right-6 p-2 hover:bg-white/10 rounded-full"><X size={24} /></button>
           <div className="flex items-center gap-4">
              <div className="p-4 bg-tk-gold rounded-2xl text-tk-dark"><UserPlus size={28} /></div>
              <div>
                <h2 className="text-2xl font-black">Novo Consumidor</h2>
                <p className="text-gray-400 text-sm">Cadastro de unidade consumidora.</p>
              </div>
           </div>
        </div>
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
           <input required value={name} onChange={e => setName(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-white font-bold outline-none" placeholder="Razão Social" />
           <input required value={uc} onChange={e => setUc(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-tk-gold font-mono font-bold outline-none" placeholder="Código UC-0000" />
           <textarea required value={address} onChange={e => setAddress(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-white font-medium outline-none h-24" placeholder="Endereço Completo" />
           <button type="submit" className="w-full bg-tk-gold text-tk-dark font-black py-5 rounded-2xl shadow-xl hover:bg-amber-400 transition-all">CADASTRAR UNIDADE</button>
        </form>
      </div>
    </div>
  );
};

interface EditableInvoiceCardProps {
  client: Client;
  selectedMonth: string;
  onUpdate: (updatedClient: Client) => void;
}

const EditableInvoiceCard: React.FC<EditableInvoiceCardProps> = ({ client, selectedMonth, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  
  // States for structured fields
  const [localName, setLocalName] = useState(client.name);
  const [localContractId, setLocalContractId] = useState(client.contractId);
  const [localDueDate, setLocalDueDate] = useState(client.lastInvoice.dueDate);
  const [localConsumption, setLocalConsumption] = useState(client.lastInvoice.consumption);

  // Extract structured values from generic items or defaults
  const findVal = (desc: string) => client.lastInvoice.items.find(i => i.description.includes(desc))?.value || 0;
  
  const [energiaAtiva, setEnergiaAtiva] = useState(findVal('Energia Ativa'));
  const [iluminacao, setIluminacao] = useState(findVal('Iluminação Pública'));
  const [bandeiraValor, setBandeiraValor] = useState(findVal('Adicional Bandeira'));
  const [bandeiraTipo, setBandeiraTipo] = useState<'Verde' | 'Amarela' | 'Vermelha'>(
    (client.lastInvoice.items.find(i => i.description.includes('Adicional Bandeira'))?.description.split(' ').pop() as any) || 'Vermelha'
  );
  const [desconto, setDesconto] = useState(findVal('Desconto') || 0);
  const [juros, setJuros] = useState(findVal('Juros') || 0);
  const [valorOriginal, setValorOriginal] = useState(findVal('Valor Original') || client.lastInvoice.amount);

  const totalCalculated = useMemo(() => {
    return (energiaAtiva + iluminacao + bandeiraValor + juros + valorOriginal) - desconto;
  }, [energiaAtiva, iluminacao, bandeiraValor, juros, valorOriginal, desconto]);

  const handleSave = () => {
    const updatedItems: InvoiceItem[] = [
      { description: 'Energia Ativa', value: energiaAtiva },
      { description: 'Iluminação Pública', value: iluminacao },
      { description: `Adicional Bandeira ${bandeiraTipo}`, value: bandeiraValor },
      { description: 'Desconto', value: desconto },
      { description: 'Juros', value: juros },
      { description: 'Valor Original', value: valorOriginal }
    ];

    onUpdate({
      ...client, 
      name: localName, 
      contractId: localContractId, 
      lastInvoice: { 
        ...client.lastInvoice, 
        amount: totalCalculated, 
        dueDate: localDueDate, 
        consumption: localConsumption, 
        items: updatedItems 
      }
    });
    setIsEditing(false);
  };

  useEffect(() => {
    setLocalName(client.name);
    setLocalContractId(client.contractId);
    setLocalDueDate(client.lastInvoice.dueDate);
    setLocalConsumption(client.lastInvoice.consumption);
    setEnergiaAtiva(findVal('Energia Ativa'));
    setIluminacao(findVal('Iluminação Pública'));
    setBandeiraValor(findVal('Adicional Bandeira'));
    setDesconto(findVal('Desconto'));
    setJuros(findVal('Juros'));
    setValorOriginal(findVal('Valor Original') || client.lastInvoice.amount);
  }, [client]);

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-[2.5rem] border border-white/20 shadow-2xl p-6 transition-all duration-300 hover:bg-white/15 flex flex-col overflow-hidden group">
      <div className="absolute top-0 right-0 w-24 h-24 bg-tk-gold/10 rounded-full blur-2xl"></div>
      <div className="mb-4 flex justify-between items-start z-10">
        <div className="space-y-1 flex-1">
          {isEditing ? (
            <div className="space-y-2 pr-4">
              <input value={localName} onChange={(e) => setLocalName(e.target.value)} className="w-full bg-white/10 border border-white/10 rounded-xl py-2 px-3 text-xs font-black text-white outline-none" placeholder="Nome" />
              <input value={localContractId} onChange={(e) => setLocalContractId(e.target.value)} className="w-full bg-white/10 border border-white/10 rounded-xl py-2 px-3 text-xs font-mono font-bold text-tk-gold outline-none" placeholder="UC" />
            </div>
          ) : (
            <>
              <h3 className="text-lg font-black text-white leading-tight">{client.name}</h3>
              <p className="text-[10px] text-tk-gold font-mono tracking-widest uppercase">{client.contractId}</p>
            </>
          )}
        </div>
        <button onClick={() => isEditing ? setIsEditing(false) : setIsEditing(true)} className="p-2 bg-white/10 text-white rounded-xl hover:bg-tk-blue/40">
          {isEditing ? <X size={14} /> : <Edit2 size={14} />}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4 z-10">
        <div className="bg-white/5 p-3 rounded-2xl border border-white/5 text-center">
          <label className="text-[9px] font-black text-gray-500 uppercase block mb-1">Vencimento</label>
          {isEditing ? <input value={localDueDate} onChange={e => setLocalDueDate(e.target.value)} className="w-full bg-transparent text-sm font-bold text-white text-center outline-none" /> : <p className="text-sm font-bold text-white">{localDueDate}</p>}
        </div>
        <div className="bg-white/5 p-3 rounded-2xl border border-white/5 text-center">
          <label className="text-[9px] font-black text-gray-500 uppercase block mb-1">Consumo</label>
          {isEditing ? <input type="number" value={localConsumption} onChange={e => setLocalConsumption(Number(e.target.value))} className="w-full bg-transparent text-sm font-bold text-white text-center outline-none" /> : <p className="text-sm font-bold text-white">{localConsumption} kWh</p>}
        </div>
      </div>

      <div className="mb-5 text-center py-4 bg-white/5 rounded-2xl border border-white/5 z-10 relative">
        <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1 block">VALOR LANÇADO</span>
        <h2 className="text-3xl font-black text-white tracking-tighter">R$ {totalCalculated.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</h2>
        {bandeiraTipo && !isEditing && (
           <div className={`absolute top-2 right-2 w-2 h-2 rounded-full ${bandeiraTipo === 'Verde' ? 'bg-green-500' : bandeiraTipo === 'Amarela' ? 'bg-yellow-500' : 'bg-red-500'}`}></div>
        )}
      </div>

      {/* Structured Items List */}
      <div className="space-y-3 flex-1 overflow-y-auto max-h-64 z-10 scrollbar-hide pr-1">
        {/* Energia Ativa */}
        <div className="flex flex-col">
          <label className="text-[8px] text-gray-500 font-black uppercase">Energia Ativa</label>
          <div className="flex justify-between items-center bg-white/5 px-3 py-2 rounded-xl mt-1 border border-white/5">
            <span className="text-[10px] text-gray-400 font-bold uppercase">R$</span>
            {isEditing ? (
              <input type="number" value={energiaAtiva} onChange={e => setEnergiaAtiva(Number(e.target.value))} className="bg-transparent text-xs font-black text-white outline-none text-right w-20" />
            ) : (
              <span className="text-xs font-black text-white">{energiaAtiva.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
            )}
          </div>
        </div>

        {/* Iluminação Pública */}
        <div className="flex flex-col">
          <label className="text-[8px] text-gray-500 font-black uppercase">Iluminação Pública</label>
          <div className="flex justify-between items-center bg-white/5 px-3 py-2 rounded-xl mt-1 border border-white/5">
            <span className="text-[10px] text-gray-400 font-bold uppercase">R$</span>
            {isEditing ? (
              <input type="number" value={iluminacao} onChange={e => setIluminacao(Number(e.target.value))} className="bg-transparent text-xs font-black text-white outline-none text-right w-20" />
            ) : (
              <span className="text-xs font-black text-white">{iluminacao.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
            )}
          </div>
        </div>

        {/* Bandeira */}
        <div className="flex flex-col">
          <div className="flex items-center justify-between">
            <label className="text-[8px] text-gray-500 font-black uppercase">Adicional Bandeira</label>
            {isEditing && (
              <div className="flex gap-1">
                {(['Verde', 'Amarela', 'Vermelha'] as const).map(tipo => (
                  <button 
                    key={tipo} 
                    onClick={() => setBandeiraTipo(tipo)}
                    className={`w-3 h-3 rounded-full transition-transform ${bandeiraTipo === tipo ? 'scale-125 border border-white' : 'opacity-50'} ${tipo === 'Verde' ? 'bg-green-500' : tipo === 'Amarela' ? 'bg-yellow-500' : 'bg-red-500'}`}
                  />
                ))}
              </div>
            )}
          </div>
          <div className={`flex justify-between items-center bg-white/5 px-3 py-2 rounded-xl mt-1 border-l-4 ${bandeiraTipo === 'Verde' ? 'border-l-green-500' : bandeiraTipo === 'Amarela' ? 'border-l-yellow-500' : 'border-l-red-500'}`}>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-gray-400 font-bold uppercase">R$</span>
            </div>
            {isEditing ? (
              <input type="number" value={bandeiraValor} onChange={e => setBandeiraValor(Number(e.target.value))} className="bg-transparent text-xs font-black text-white outline-none text-right w-20" />
            ) : (
              <span className="text-xs font-black text-white">{bandeiraValor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
            )}
          </div>
        </div>

        {/* Desconto */}
        <div className="flex flex-col">
          <label className="text-[8px] text-gray-500 font-black uppercase text-green-500">Desconto Original</label>
          <div className="flex justify-between items-center bg-green-500/5 px-3 py-2 rounded-xl mt-1 border border-green-500/10">
            <span className="text-[10px] text-green-500/50 font-bold uppercase">R$</span>
            {isEditing ? (
              <input type="number" value={desconto} onChange={e => setDesconto(Number(e.target.value))} className="bg-transparent text-xs font-black text-green-400 outline-none text-right w-20" />
            ) : (
              <span className="text-xs font-black text-green-400">-{desconto.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
            )}
          </div>
        </div>

        {/* Juros */}
        <div className="flex flex-col">
          <label className="text-[8px] text-gray-500 font-black uppercase text-red-400">Juros</label>
          <div className="flex justify-between items-center bg-red-500/5 px-3 py-2 rounded-xl mt-1 border border-red-500/10">
            <span className="text-[10px] text-red-500/50 font-bold uppercase">R$</span>
            {isEditing ? (
              <input type="number" value={juros} onChange={e => setJuros(Number(e.target.value))} className="bg-transparent text-xs font-black text-red-400 outline-none text-right w-20" />
            ) : (
              <span className="text-xs font-black text-red-400">+{juros.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
            )}
          </div>
        </div>

        {/* Valor Original */}
        <div className="flex flex-col">
          <label className="text-[8px] text-gray-500 font-black uppercase">Valor Original da Conta</label>
          <div className="flex justify-between items-center bg-white/10 px-3 py-2 rounded-xl mt-1 border border-white/20">
            <span className="text-[10px] text-gray-400 font-bold uppercase">R$</span>
            {isEditing ? (
              <input type="number" value={valorOriginal} onChange={e => setValorOriginal(Number(e.target.value))} className="bg-transparent text-xs font-black text-white outline-none text-right w-20" />
            ) : (
              <span className="text-xs font-black text-white">{valorOriginal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
            )}
          </div>
        </div>
      </div>

      {isEditing ? (
        <button onClick={handleSave} className="w-full mt-6 py-4 bg-tk-gold text-tk-dark rounded-2xl font-black text-xs uppercase shadow-xl hover:scale-[1.02] transition-all">SALVAR ALTERAÇÕES</button>
      ) : (
        <button className="w-full mt-6 py-4 bg-white/10 text-white rounded-2xl text-xs font-black uppercase border border-white/10 hover:bg-tk-blue transition-all">GERAR RELATÓRIO</button>
      )}
    </div>
  );
};

const InvoiceDataView = ({ 
  clients, 
  onUpdateClient, 
  onAddClient,
  selectedMonth, 
  onSelectMonth 
}: { 
  clients: Client[], 
  onUpdateClient: (updated: Client) => void,
  onAddClient: () => void,
  selectedMonth: string,
  onSelectMonth: (m: string) => void
}) => {
  return (
    <DarkThemeWrapper>
      <div className="space-y-8">
        <div className="space-y-2">
          <h1 className="text-4xl font-black text-white tracking-tighter">
            Dados de Fatura - <span className="text-tk-gold">Gestão Mensal</span>
          </h1>
          <p className="text-gray-400 font-medium text-lg">Atualize e sincronize os dados de cobrança com campos padronizados.</p>
        </div>

        <div className="bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-white/10 space-y-4 shadow-xl">
           <div className="flex items-center justify-between">
             <p className="text-[10px] font-black text-tk-gold uppercase tracking-[0.25em]">Sincronização de Período & Cadastro</p>
           </div>
           <MonthSelector selectedMonth={selectedMonth} onSelect={onSelectMonth} onAddClient={onAddClient} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {clients.map((client) => (
            <EditableInvoiceCard key={client.id} client={client} selectedMonth={selectedMonth} onUpdate={onUpdateClient} />
          ))}
        </div>
      </div>
    </DarkThemeWrapper>
  );
};

const ClientDashboard = ({ client, onBack }: { client: Client; onBack: () => void }) => {
  // Extract values for the dashboard
  const findVal = (desc: string) => client.lastInvoice.items.find(i => i.description.includes(desc))?.value || 0;
  const discountVal = findVal('Desconto');
  const originalVal = findVal('Valor Original') || (client.lastInvoice.amount + discountVal);

  return (
    <div className="space-y-8 animate-slide-up pb-10">
      {/* HEADER SECTION RESTRUCTURED */}
      <div className="flex flex-col gap-6 bg-white/40 backdrop-blur-md p-8 rounded-[3rem] border border-white/60 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-tk-blue/5 rounded-full blur-2xl"></div>
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-5">
            <button onClick={onBack} className="p-4 bg-white hover:bg-tk-blue hover:text-white text-gray-400 rounded-[1.5rem] shadow-sm border border-gray-100 transition-all active:scale-90 group">
              <ChevronLeft size={28} className="group-hover:-translate-x-1 transition-transform" />
            </button>
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-3">
                 <h2 className="text-3xl font-black text-tk-dark tracking-tight">{client.name}</h2>
                 <span className="text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-full bg-tk-blue/10 text-tk-blue border border-tk-blue/20">UNIDADE ATIVA</span>
              </div>
              
              <div className="flex flex-wrap items-center gap-4">
                <div className="flex items-center gap-2 px-3 py-2 bg-tk-dark/5 rounded-2xl border border-tk-dark/10">
                   <div className="p-1.5 bg-tk-dark text-white rounded-lg">
                     <Layers size={14} />
                   </div>
                   <span className="text-sm font-black text-tk-dark/60 font-mono tracking-wider">{client.contractId}</span>
                </div>
                
                <div className="flex items-center gap-2 px-3 py-2 bg-tk-gold/10 rounded-2xl border border-tk-gold/20">
                   <div className="p-1.5 bg-tk-gold text-tk-dark rounded-lg">
                     <Calendar size={14} />
                   </div>
                   <div className="flex flex-col leading-none">
                     <span className="text-[9px] font-black text-tk-gold uppercase tracking-tighter">VENCIMENTO</span>
                     <span className="text-sm font-black text-tk-dark">{client.lastInvoice.dueDate}</span>
                   </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex gap-3">
             <button className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-white/80 hover:bg-white text-tk-dark border border-white/80 font-bold py-4 px-8 rounded-2xl transition-all shadow-sm">
                <Mail size={20} className="text-tk-blue" /> Notificar
             </button>
             <button className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-tk-blue hover:bg-tk-dark text-white font-bold py-4 px-10 rounded-2xl shadow-lg transition-all hover:scale-[1.02] active:scale-95">
                <Download size={20} /> Baixar PDF
             </button>
          </div>
        </div>
        
        <div className="flex items-center gap-2 px-4 py-2 bg-white/40 rounded-2xl w-fit border border-white/60">
           <MapPin size={14} className="text-tk-gold" />
           <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">{client.address}</span>
        </div>
      </div>

      {/* METRICS GRID - ENLARGED SIZES */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="group relative bg-white/80 backdrop-blur-xl p-8 rounded-[3rem] border border-white/60 shadow-xl transition-all hover:scale-[1.03]">
          <div className="absolute -right-4 -top-4 w-40 h-40 bg-tk-gold/5 rounded-full blur-3xl"></div>
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3 text-tk-blue">
              <div className="p-4 bg-tk-blue/10 rounded-[1.8rem]"><DollarSign size={28} /></div>
              <span className="text-sm font-black uppercase tracking-widest">Fatura Atual</span>
            </div>
            <div className="bg-green-100 text-green-700 px-3 py-1.5 rounded-xl text-xs font-black">LÍQUIDO</div>
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-bold text-gray-400 uppercase mb-1">Total a Pagar</span>
            <h4 className="text-5xl font-black text-tk-dark tracking-tighter">R$ {client.lastInvoice.amount.toLocaleString('pt-BR')}</h4>
          </div>
        </div>

        <div className="group relative bg-white/80 backdrop-blur-xl p-8 rounded-[3rem] border border-white/60 shadow-xl transition-all hover:scale-[1.03]">
          <div className="flex items-center gap-3 text-tk-gold mb-8">
            <div className="p-4 bg-tk-gold/10 rounded-[1.8rem]"><Zap size={28} /></div>
            <span className="text-sm font-black uppercase tracking-widest">Consumo Total</span>
          </div>
          <div className="flex flex-col">
             <span className="text-xs font-bold text-gray-400 uppercase mb-1">Ciclo Mensal</span>
             <h4 className="text-5xl font-black text-tk-dark tracking-tighter">{client.lastInvoice.consumption} <span className="text-2xl text-gray-300 font-bold ml-1">kWh</span></h4>
          </div>
        </div>

        <div className="group relative bg-white/80 backdrop-blur-xl p-8 rounded-[3rem] border border-white/60 shadow-xl transition-all hover:scale-[1.03] overflow-hidden">
          <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-green-500/5 rounded-full blur-3xl"></div>
          <div className="flex items-center gap-3 text-green-500 mb-8">
            <div className="p-4 bg-green-500/10 rounded-[1.8rem]"><Tag size={28} /></div>
            <span className="text-sm font-black uppercase tracking-widest">Valor de Desconto</span>
          </div>
          <div className="flex flex-col">
             <span className="text-xs font-bold text-gray-400 uppercase mb-1">Economia Gerada</span>
             <h4 className="text-5xl font-black text-green-600 tracking-tighter">R$ {discountVal.toLocaleString('pt-BR')}</h4>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white/90 backdrop-blur-md p-10 rounded-[3.5rem] border border-white/60 shadow-sm flex flex-col">
          <div className="flex items-center justify-between mb-12">
            <h3 className="text-2xl font-black text-tk-dark flex items-center gap-3">
              <TrendingDown className="text-tk-blue" size={24} /> 
              Histórico de Consumo
            </h3>
            <div className="flex gap-2">
              <div className="w-3 h-3 rounded-full bg-tk-blue"></div>
              <div className="w-3 h-3 rounded-full bg-tk-gold"></div>
            </div>
          </div>
          <div className="h-80 w-full mt-auto">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={client.history} margin={{ left: -25, top: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f1f1" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill: '#9CA3AF', fontSize: 13, fontWeight: 800}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#9CA3AF', fontSize: 12}} />
                <Tooltip cursor={{fill: '#F9FAFB', radius: 12}} contentStyle={{borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.15)'}} />
                <Bar dataKey="kwh" radius={[16, 16, 6, 6]} barSize={45}>
                  {client.history.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === (client.history.length - 1) ? '#FFAA00' : '#005792'} fillOpacity={0.9} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-tk-dark p-10 rounded-[3.5rem] shadow-2xl flex flex-col text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-tk-blue/10 rounded-full blur-[100px]"></div>
          <div className="flex items-center justify-between mb-10">
            <h3 className="text-2xl font-black text-tk-gold flex items-center gap-3">
              <Info size={24} /> 
              Detalhamento Técnico
            </h3>
            <div className="px-4 py-1.5 bg-white/5 rounded-full border border-white/10 text-[10px] font-black uppercase tracking-widest">
              Fatura Ref. Nov/23
            </div>
          </div>
          
          <div className="flex-1 overflow-auto pr-4 scrollbar-hide">
            <table className="w-full">
              <tbody className="divide-y divide-white/10">
                {client.lastInvoice.items.map((item, idx) => (
                  <tr key={idx} className="group hover:bg-white/5 transition-all">
                    <td className="py-6 text-sm text-gray-300 font-bold uppercase tracking-tight group-hover:text-white transition-colors">
                      {item.description}
                    </td>
                    <td className="py-6 text-base font-black text-white text-right">
                      R$ {item.value.toFixed(2).replace('.', ',')}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-tk-gold/30">
                  <td className="py-10 font-black text-tk-gold text-sm uppercase tracking-[0.2em]">Total Líquido</td>
                  <td className="py-10 text-4xl font-black text-right tracking-tighter">
                    R$ {client.lastInvoice.amount.toLocaleString('pt-BR')}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
          
          <div className="mt-6 p-6 bg-white/5 rounded-3xl border border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <ShieldCheck className="text-tk-gold" size={20} />
              <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Verificado por TK Energy</span>
            </div>
            <ArrowUpRight size={20} className="text-tk-gold" />
          </div>
        </div>
      </div>
    </div>
  );
};

const LoginScreen = ({ onLogin }: { onLogin: () => void }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin();
    }, 1000);
  };

  const benefits = [
    {
      icon: <Sun className="text-white" size={24} />,
      title: "Redução de até 95%",
      desc: "Economia real na sua conta de energia.",
      color: "bg-white/10"
    },
    {
      icon: <Leaf className="text-white" size={24} />,
      title: "Futuro Sustentável",
      desc: "Energia limpa e renovável.",
      color: "bg-white/10"
    },
    {
      icon: <Activity className="text-white" size={24} />,
      title: "Tecnologia e Excelência",
      desc: "Monitoramento inteligente do seu consumo.",
      color: "bg-white/10"
    },
    {
      icon: <Heart className="text-white" size={24} />,
      title: "Compromisso",
      desc: "Atendimento dedicado a cada cliente.",
      color: "bg-white/10"
    }
  ];

  return (
    <div className="min-h-screen flex bg-white font-sans overflow-hidden">
      {/* Coluna Esquerda: Marketing/Branding */}
      <div className="hidden lg:flex lg:w-[45%] bg-tk-dark relative flex-col justify-between p-16 text-white">
        <div className="relative z-10">
          <Logo variant="light" orientation="horizontal" className="h-20 justify-start" />
        </div>

        <div className="relative z-10 space-y-12">
          <h1 className="text-5xl font-black leading-tight tracking-tighter">
            <span className="text-tk-gold">Energia</span> que transforma o presente e <span className="text-tk-gold">ilumina</span> o futuro.
          </h1>

          <div className="space-y-8">
            {benefits.map((benefit, i) => (
              <div key={i} className="flex items-start gap-5">
                <div className={`${benefit.color} p-4 rounded-2xl shadow-inner`}>
                  {benefit.icon}
                </div>
                <div>
                  <h3 className="text-xl font-black tracking-tight">{benefit.title}</h3>
                  <p className="text-gray-400 text-sm font-medium">{benefit.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative z-10 pt-8 border-t border-white/5 flex items-center justify-between text-sm text-gray-400">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Phone size={16} className="text-tk-gold" /> (85) 9 9725-4532
            </div>
            <div className="flex items-center gap-2">
              <MapPin size={16} className="text-tk-gold" /> Fortaleza, CE
            </div>
          </div>
        </div>
      </div>

      {/* Coluna Direita: Formulário de Login */}
      <div className="w-full lg:w-[55%] flex flex-col items-center justify-center p-8 md:p-24 relative bg-white">
        <div className="w-full max-w-md space-y-10">
          <div className="text-center lg:text-left space-y-3">
            <div className="lg:hidden flex justify-center mb-8">
               <Logo variant="dark" orientation="vertical" className="h-24" />
            </div>
            <h2 className="text-4xl font-black text-tk-dark tracking-tighter">Bem-vindo Gestor TK ENERGY</h2>
            <p className="text-gray-500 font-medium">Acesse o portal para gerenciar suas faturas.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-black text-tk-dark uppercase tracking-widest ml-1">E-mail</label>
              <div className="relative group">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-tk-gold transition-colors" size={20} />
                <input 
                  type="email" 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-12 pr-4 py-5 bg-gray-50 border border-gray-200 rounded-2xl focus:bg-white focus:ring-2 focus:ring-tk-gold outline-none transition-all font-bold text-lg text-tk-dark placeholder:text-gray-400"
                  placeholder="ex: nome@empresa.com" 
                  required 
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-black text-tk-dark uppercase tracking-widest ml-1">Senha</label>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-tk-gold transition-colors" size={20} />
                <input 
                  type={showPassword ? "text" : "password"} 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-12 pr-12 py-5 bg-gray-50 border border-gray-200 rounded-2xl focus:bg-white focus:ring-2 focus:ring-tk-gold outline-none transition-all font-bold text-lg text-tk-dark placeholder:text-gray-400"
                  placeholder="••••••••" 
                  required 
                />
                <button 
                  type="button" 
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-tk-dark"
                >
                  {showPassword ? <EyeOff size={22} /> : <Eye size={22} />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-sm font-bold">
              <label className="flex items-center gap-2 cursor-pointer text-gray-500">
                <input type="checkbox" className="w-4 h-4 rounded-md border-gray-200 text-tk-gold focus:ring-tk-gold" />
                Lembrar-me
              </label>
              <a href="#" className="text-tk-gold hover:underline">Esqueceu a senha?</a>
            </div>

            <button 
              type="submit" 
              disabled={isLoading}
              className="w-full bg-tk-gold hover:bg-[#FFB700] text-tk-dark font-black py-5 rounded-2xl shadow-[0_10px_30px_rgba(255,170,0,0.3)] transition-all flex items-center justify-center gap-3 text-lg active:scale-95 disabled:opacity-50"
            >
              {isLoading ? (
                <div className="w-6 h-6 border-3 border-tk-dark border-t-transparent rounded-full animate-spin"></div>
              ) : (
                "Acessar Área do Cliente"
              )}
            </button>
          </form>

          <div className="space-y-6 pt-6 text-center">
            <div className="flex items-center justify-center gap-2 px-6 py-2 bg-green-50 rounded-full inline-flex border border-green-100 mx-auto">
              <ShieldCheck size={16} className="text-green-500" />
              <span className="text-xs font-black text-green-700 uppercase tracking-widest">Ambiente 100% Seguro</span>
            </div>

            <div className="flex flex-col space-y-4">
               <div className="flex justify-center gap-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                 <a href="#" className="hover:text-tk-dark">Política de Privacidade</a>
                 <span className="text-gray-200">•</span>
                 <a href="#" className="hover:text-tk-dark">Termos de Uso</a>
               </div>
               <p className="text-sm font-medium text-gray-500">
                 Ainda não é cliente? <a href="#" className="text-tk-blue font-black hover:underline">Solicite uma proposta</a>
               </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [view, setView] = useState<'list' | 'details' | 'invoice-data' | 'financial-report'>('list');
  const [clients, setClients] = useState<Client[]>(MOCK_CLIENTS);
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);
  const [selectedMonth, setSelectedMonth] = useState('NOV');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isPlantModalOpen, setIsPlantModalOpen] = useState(false);

  // Local state for management data
  const [summary, setSummary] = useState<FinancialSummary>(MOCK_FINANCIAL);
  const [plants, setPlants] = useState<Plant[]>(MOCK_PLANTS);

  const selectedClient = useMemo(() => clients.find(c => c.id === selectedClientId) || null, [clients, selectedClientId]);

  const handleLogout = () => { setIsAuthenticated(false); setView('list'); setSelectedClientId(null); };
  const handleUpdateClient = (updatedClient: Client) => { setClients(prev => prev.map(c => c.id === updatedClient.id ? updatedClient : c)); };
  const handleAddClient = (newClient: Client) => { setClients(prev => [newClient, ...prev]); };

  const handleUpdatePlant = (updatedPlant: Plant) => {
    setPlants(prev => prev.map(p => p.id === updatedPlant.id ? updatedPlant : p));
  };

  const handleAddPlant = (newPlant: Plant) => {
    setPlants(prev => [newPlant, ...prev]);
  };

  if (!isAuthenticated) return <LoginScreen onLogin={() => setIsAuthenticated(true)} />;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      <DesktopHeader currentView={view} onNavigate={(v) => setView(v as any)} onLogout={handleLogout} />
      <main className="flex-1 w-full max-w-7xl mx-auto p-2 md:p-8">
        <div className="md:hidden flex justify-between items-center mb-6 pt-2 px-4">
          <Logo className="h-10" />
          <button onClick={handleLogout} className="p-2 text-gray-400"><LogOut size={20} /></button>
        </div>
        
        {view === 'list' && (
          <ManagementGrid clients={clients} selectedMonth={selectedMonth} onSelectMonth={setSelectedMonth} onSelectClient={(c) => { setSelectedClientId(c.id); setView('details'); }} />
        )}
        
        {view === 'details' && selectedClient && (
          <ClientDashboard client={selectedClient} onBack={() => setView('list')} />
        )}

        {view === 'invoice-data' && (
          <InvoiceDataView clients={clients} selectedMonth={selectedMonth} onSelectMonth={setSelectedMonth} onUpdateClient={handleUpdateClient} onAddClient={() => setIsModalOpen(true)} />
        )}

        {view === 'financial-report' && (
          <FinancialReportView 
            summary={summary} 
            clients={clients} 
            plants={plants}
            onUpdateSummary={setSummary}
            onUpdatePlant={handleUpdatePlant}
            onAddPlant={() => setIsPlantModalOpen(true)}
          />
        )}
      </main>

      <NewClientModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSave={handleAddClient} />
      <NewPlantModal isOpen={isPlantModalOpen} onClose={() => setIsPlantModalOpen(false)} onSave={handleAddPlant} />
      
      <BottomNavigation currentView={view} onNavigate={(v) => setView(v as any)} onLogout={handleLogout} />

      <style>{`
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade-in { animation: fadeIn 0.4s ease-out; }
        .animate-slide-up { animation: slideUp 0.6s cubic-bezier(0.16, 1, 0.3, 1); }
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default App;
