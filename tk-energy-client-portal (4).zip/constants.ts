
import { ChartData, Invoice, User, Client, Plant, FinancialSummary } from './types';

export const MOCK_USER: User = {
  name: "Gestor TK",
  email: "admin@tkenergy.com.br",
  contractId: "TK-ADMIN-01"
};

export const MOCK_FINANCIAL: FinancialSummary = {
  revenue: 154200.50,
  payments: 82340.20,
  profit: 71860.30,
  growthPercent: 15.4
};

export const MOCK_PLANTS: Plant[] = [
  {
    id: 'p1',
    name: 'Solar Park Delta',
    location: 'Aquiraz / CE',
    inverterBrand: 'Huawei',
    generationToday: 450.5,
    generationMonth: 12.4,
    trend: [10, 15, 8, 20, 25, 18, 22]
  },
  {
    id: 'p2',
    name: 'UFV Horizonte',
    location: 'Pacajus / CE',
    inverterBrand: 'Fronius',
    generationToday: 320.2,
    generationMonth: 8.9,
    trend: [12, 10, 15, 14, 18, 16, 15]
  },
  {
    id: 'p3',
    name: 'Fazenda Solar TK-01',
    location: 'Quixadá / CE',
    inverterBrand: 'Growatt',
    generationToday: 890.0,
    generationMonth: 24.5,
    trend: [30, 35, 32, 40, 45, 42, 48]
  },
  {
    id: 'p4',
    name: 'Geração Eco Valley',
    location: 'Sobral / CE',
    inverterBrand: 'Huawei',
    generationToday: 560.8,
    generationMonth: 15.2,
    trend: [20, 22, 18, 25, 24, 28, 30]
  }
];

export const MOCK_CLIENTS: Client[] = [
  {
    id: '1',
    name: 'Condomínio Solar Horizonte',
    contractId: 'UC-9725-4532',
    status: 'Em dia',
    address: 'Av. Beira Mar, 1200 - Fortaleza, CE',
    totalDiscountGenerated: 450.20,
    lastInvoice: {
      amount: 1250.40,
      consumption: 1120,
      dueDate: '10/12/2023',
      items: [
        { description: 'Energia Ativa (TUSD/TE)', value: 980.50 },
        { description: 'Iluminação Pública', value: 45.00 },
        { description: 'Adicional Bandeira Vermelha', value: 52.14 },
        { description: 'Tributos (ICMS/PIS/COFINS)', value: 172.76 }
      ]
    },
    history: [
      { month: 'Jul', kwh: 980, amount: 1050 },
      { month: 'Ago', kwh: 1150, amount: 1280 },
      { month: 'Set', kwh: 1020, amount: 1120 },
      { month: 'Out', kwh: 1080, amount: 1190 },
      { month: 'Nov', kwh: 1120, amount: 1250.40 },
      { month: 'Dez', kwh: 1100, amount: 1230 }
    ]
  },
  {
    id: '2',
    name: 'Mercado Central Sul',
    contractId: 'UC-8812-4400',
    status: 'Pendente',
    address: 'Rua Castro e Silva, 450 - Centro',
    totalDiscountGenerated: 1240.80,
    lastInvoice: {
      amount: 3450.80,
      consumption: 3200,
      dueDate: '05/12/2023',
      items: [
        { description: 'Consumo Ponta', value: 1800.50 },
        { description: 'Consumo Fora Ponta', value: 1150.30 },
        { description: 'Contribuição Iluminação', value: 85.00 },
        { description: 'Encargos e Impostos', value: 415.00 }
      ]
    },
    history: [
      { month: 'Jul', kwh: 2900, amount: 3100 },
      { month: 'Ago', kwh: 3100, amount: 3350 },
      { month: 'Set', kwh: 3050, amount: 3280 },
      { month: 'Out', kwh: 3300, amount: 3550 },
      { month: 'Nov', kwh: 3200, amount: 3450.80 },
      { month: 'Dez', kwh: 3150, amount: 3400 }
    ]
  },
  {
    id: '3',
    name: 'Padaria Alfa & Ômega',
    contractId: 'UC-3344-9981',
    status: 'Em dia',
    address: 'Rua dos Padeiros, 12 - Aldeota',
    totalDiscountGenerated: 320.50,
    lastInvoice: {
      amount: 1120.45,
      consumption: 1150,
      dueDate: '15/12/2023',
      items: [
        { description: 'Energia Elétrica Comercial', value: 950.00 },
        { description: 'Taxa de Iluminação', value: 45.00 },
        { description: 'Multas/Juros anteriores', value: 0.00 },
        { description: 'Impostos Federais/Estaduais', value: 125.45 }
      ]
    },
    history: [
      { month: 'Jul', kwh: 1050, amount: 980 },
      { month: 'Ago', kwh: 1100, amount: 1050 },
      { month: 'Set', kwh: 1080, amount: 1020 },
      { month: 'Out', kwh: 1120, amount: 1100 },
      { month: 'Nov', kwh: 1150, amount: 1120.45 },
      { month: 'Dez', kwh: 1140, amount: 1110 }
    ]
  },
  {
    id: '4',
    name: 'Residência Silva Neto',
    contractId: 'UC-1100-2233',
    status: 'Em dia',
    address: 'Av. Washington Soares, 4000 - Edson Queiroz',
    totalDiscountGenerated: 85.30,
    lastInvoice: {
      amount: 450.20,
      consumption: 410,
      dueDate: '20/12/2023',
      items: [
        { description: 'Energia Ativa Requisitada', value: 380.00 },
        { description: 'Iluminação Pública Municipal', value: 15.00 },
        { description: 'Bandeira Tarifária Aplicada', value: 12.00 },
        { description: 'Tributos Incidentes', value: 43.20 }
      ]
    },
    history: [
      { month: 'Jul', kwh: 380, amount: 410 },
      { month: 'Ago', kwh: 400, amount: 430 },
      { month: 'Set', kwh: 420, amount: 460 },
      { month: 'Out', kwh: 390, amount: 420 },
      { month: 'Nov', kwh: 410, amount: 450.20 },
      { month: 'Dez', kwh: 405, amount: 445 }
    ]
  }
];

export const CONSUMPTION_DATA: ChartData[] = MOCK_CLIENTS[0].history;

export const INVOICES: Invoice[] = [
  {
    id: 'INV-2023-011',
    month: 'Novembro',
    year: 2023,
    consumptionKwh: 698,
    amount: 762.59,
    status: 'pending',
    dueDate: '10/12/2023',
    downloadUrl: '#',
    tusdTeAmount: 850.45,
    redFlagAmount: 42.50,
    cipAmount: 35.00,
    otherChargesAmount: 18.25,
    solarCompensatedKwh: 150,
    solarCreditAmount: -183.61
  }
];
