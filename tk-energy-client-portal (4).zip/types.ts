
export interface ConsumptionHistory {
  month: string;
  kwh: number;
  amount: number;
}

export interface InvoiceItem {
  description: string;
  value: number;
}

export interface Client {
  id: string;
  name: string;
  contractId: string;
  status: 'Em dia' | 'Pendente';
  address: string;
  lastInvoice: {
    amount: number;
    consumption: number;
    dueDate: string;
    items: InvoiceItem[];
  };
  history: ConsumptionHistory[];
  totalDiscountGenerated?: number;
}

export interface Plant {
  id: string;
  name: string;
  location: string;
  inverterBrand: 'Huawei' | 'Fronius' | 'Growatt';
  generationToday: number;
  generationMonth: number;
  trend: number[];
}

export interface FinancialSummary {
  revenue: number;
  payments: number;
  profit: number;
  growthPercent: number;
}

export interface Invoice {
  id: string;
  month: string;
  year: number;
  consumptionKwh: number;
  amount: number;
  status: 'paid' | 'pending' | 'overdue';
  dueDate: string;
  downloadUrl: string;
  tusdTeAmount: number;
  redFlagAmount: number;
  cipAmount: number;
  otherChargesAmount: number;
  solarCompensatedKwh: number;
  solarCreditAmount: number;
}

export interface User {
  name: string;
  email: string;
  contractId: string;
}

export interface ChartData {
  month: string;
  kwh: number;
  amount: number;
}
