import React from 'react';

interface LogoProps {
  className?: string;
  variant?: 'light' | 'dark';
  orientation?: 'horizontal' | 'vertical';
}

export const Logo: React.FC<LogoProps> = ({ 
  className = "h-12", 
  variant = 'dark',
  orientation = 'horizontal' 
}) => {
  const textColor = variant === 'light' ? 'text-white' : 'text-tk-dark';
  
  return (
    <div className={`flex ${orientation === 'vertical' ? 'flex-col space-y-4' : 'flex-row space-x-3'} items-center justify-center ${className}`}>
      {/* Icon */}
      <div className={`relative aspect-square ${orientation === 'vertical' ? 'h-32 w-32' : 'h-full'}`}>
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-md" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Main Circle - Gold Background for Sky */}
          <circle cx="50" cy="50" r="48" fill="#FFAA00" />

          {/* Sun Rays */}
          <g>
            {[...Array(7)].map((_, i) => {
              // Fan rays out from the top
              const angle = -75 + (i * 25); 
              return (
                <path
                  key={i}
                  d="M50 50 L50 12 L54 50 Z" 
                  fill="white"
                  transform={`rotate(${angle} 50 50)`}
                />
              );
            })}
          </g>

          {/* Sun Body - White Semicircle */}
          <circle cx="50" cy="50" r="15" fill="white" />

          {/* Panels Area - Blue Hill/Horizon */}
          <path d="M-5 60 Q50 42 105 60 V105 H-5 Z" fill="#005792" />
          
          {/* Grid Lines on Panels */}
          <g stroke="white" strokeWidth="1.5" strokeLinecap="round">
             {/* Verticals (Perspective) */}
             <path d="M50 42 L50 100" />
             <path d="M35 45 L25 100" />
             <path d="M65 45 L75 100" />
             <path d="M20 50 L5 100" />
             <path d="M80 50 L95 100" />
             
             {/* Horizontals (Curved) */}
             <path d="M5 65 Q50 52 95 65" strokeWidth="1" />
             <path d="M2 77 Q50 64 98 77" strokeWidth="1" />
             <path d="M0 88 Q50 75 100 88" strokeWidth="1" />
          </g>

          {/* Outer Ring */}
          <circle cx="50" cy="50" r="46" stroke="#00204A" strokeWidth="6" fill="none" />
        </svg>
      </div>
      
      {/* Text */}
      <div className={`flex flex-col items-${orientation === 'vertical' ? 'center' : 'start'} ${textColor}`}>
         <span className={`${orientation === 'vertical' ? 'text-3xl' : 'text-xl'} font-black tracking-wider leading-none`}>
           TK ENERGY
         </span>
         {orientation === 'horizontal' && (
           <span className="text-[0.6rem] uppercase tracking-widest opacity-80 font-medium mt-0.5">
             Energia que transforma
           </span>
         )}
      </div>
    </div>
  );
};