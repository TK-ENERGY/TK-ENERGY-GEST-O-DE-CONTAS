
import React from 'react';
import { LayoutDashboard, FileText, LogOut, Database, BarChart3 } from 'lucide-react';
import { Logo } from './Logo';

interface NavigationProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onLogout: () => void;
}

export const BottomNavigation: React.FC<NavigationProps> = ({ currentView, onNavigate }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-3 flex justify-around items-center z-50 md:hidden shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
      <button 
        onClick={() => onNavigate('list')}
        className={`flex flex-col items-center space-y-1 ${currentView === 'list' ? 'text-tk-blue' : 'text-gray-400'}`}
      >
        <LayoutDashboard size={24} />
        <span className="text-xs font-medium">Início</span>
      </button>
      <button 
        onClick={() => onNavigate('invoice-data')}
        className={`flex flex-col items-center space-y-1 ${currentView === 'invoice-data' ? 'text-tk-blue' : 'text-gray-400'}`}
      >
        <Database size={24} />
        <span className="text-xs font-medium">Dados</span>
      </button>
      <button 
        onClick={() => onNavigate('financial-report')}
        className={`flex flex-col items-center space-y-1 ${currentView === 'financial-report' ? 'text-tk-blue' : 'text-gray-400'}`}
      >
        <BarChart3 size={24} />
        <span className="text-xs font-medium">Gestão TK</span>
      </button>
    </div>
  );
};

export const DesktopHeader: React.FC<NavigationProps> = ({ currentView, onNavigate, onLogout }) => {
  return (
    <header className="hidden md:flex bg-tk-dark text-white px-8 py-3 justify-between items-center shadow-md sticky top-0 z-50">
      <div className="flex items-center gap-8">
        <Logo variant="light" className="h-14" />
        <nav className="flex gap-6 ml-4">
           <button 
            onClick={() => onNavigate('list')}
            className={`text-sm font-medium hover:text-tk-gold transition-colors ${currentView === 'list' || currentView === 'details' ? 'text-tk-gold border-b-2 border-tk-gold' : 'text-gray-300'}`}
          >
            Dashboard
          </button>
          <button 
            onClick={() => onNavigate('invoice-data')}
            className={`text-sm font-medium hover:text-tk-gold transition-colors ${currentView === 'invoice-data' ? 'text-tk-gold border-b-2 border-tk-gold' : 'text-gray-300'}`}
          >
            Dados de Faturas
          </button>
          <button 
            onClick={() => onNavigate('financial-report')}
            className={`text-sm font-medium hover:text-tk-gold transition-colors ${currentView === 'financial-report' ? 'text-tk-gold border-b-2 border-tk-gold' : 'text-gray-300'}`}
          >
            Gestão TK ENERGY
          </button>
          <button 
            onClick={() => {}} // Placeholder para futuras visões
            className={`text-sm font-medium text-gray-500 cursor-not-allowed`}
            disabled
          >
            Minhas Faturas
          </button>
        </nav>
      </div>
      <button 
        onClick={onLogout}
        className="flex items-center gap-2 text-sm text-gray-300 hover:text-white transition-colors"
      >
        <LogOut size={16} />
        Sair
      </button>
    </header>
  );
};
